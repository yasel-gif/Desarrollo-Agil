package cursoDAgil.dao.ventas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.dao.cliente.ClienteDao;
import cursoDAgil.dao.productos.ProductosDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class VentasDaoImplTest {
	@Inject
	VentasDao ventasDao;
	@Inject
	ClienteDao clienteDao;
	@Inject
	ProductosDao productosDao;
	
	@Ignore
	//@Test
	public void consultarVentasPorId() {
		Ventas ventas = new Ventas();
		Map<String, Integer> mapVentas = new HashMap<>();
		mapVentas.put("idVenta", 2);
		try {
			ventas = ventasDao.obtenerVentasPorId(mapVentas);
			assertNotNull(ventas);
			System.out.println("id:" + ventas.getIdVenta());
			System.out.println("Id cliente:" + ventas.getClienteId());
			System.out.println(" cliente:" + ventas.getCliente().getNombre());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void pruebaConsultarTodo2() {
		Map<String, Integer> mapVentas = new HashMap<>();
		mapVentas.put("idVenta",6 );
		int reg;
		System.out.println("Test consultar todas los Ventas por id");
		try {
			//Ventas v = ventasDao.obtenerVentas2();
			
			
				//System.out.println("id:" + v.getIdVenta());
				//List<DetalleVentas> dv= v.getDetallesVentas();
				/*for(DetalleVentas dev: v.getDetallesVentas() ){
					System.out.println("dv: " + dev.getProductos().getIdProducto());
					System.out.println("dv: " + dev.getProductos().getNombre());
					System.out.println("ddv: " + dev.getCantidad());
				}*/
				
				
				
			
			
			
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	
	//@Test
	@Ignore
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas los Ventas");
		try {
			List<Ventas> list = ventasDao.obtenerVentas();
			reg = list.size();
			for(Ventas v:list) {
				System.out.println("id:" + v.getIdVenta());
				System.out.println("id cliente:" + v.getCliente().getId());
				//System.out.println("total venta:" + v.getTotalVenta());
				//System.out.println(" cliente:" + v.getCliente().getNombre());
				//System.out.println(" ciudad:" + v.getCliente().getDireccion().getCalle());
				
				
			}
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	@Ignore
	//@Test
	public void nuevoRegistro2() {
		Ventas ventas = new Ventas();
		System.out.println("Test nuevo registro");
		try {
			ventas.setClienteId(9);
			ventas.setTotalVenta(50840.0);
			ventas.setFecha("2021-04-24");
			
			ventasDao.nuevaVentas(ventas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void nuevoRegistro() {
		Ventas nuevaVentas = new Ventas();
		List<Productos> carrito= new ArrayList<Productos>();
		Cliente cliente = new Cliente();
		Integer id=0;
		Double totalVenta=0.0;
		//System.out.println("Test nuevo venta");
		try {
			Map<String, Integer> mapVentas = new HashMap<>();
			mapVentas.put("id", 9);
			cliente= clienteDao.obtenerClientePorId(mapVentas) ;
			id=cliente.getId();
			//System.out.print("id\n "+ id);
			nuevaVentas.setClienteId(id);
			//System.out.print("s\n "+ nuevaVentas.getIdVenta());
			for(int i=4; i<=5; i++) {
				Productos productos= new Productos();
				mapVentas.put("idProducto", i);
				//System.out.print("id "+ i);
				productos=productosDao.obtenerProductosPorId(mapVentas);
				assertNotNull(productos);
				productos.setCantidad(4);
				totalVenta+=productos.getCantidad()*productos.getPrecioVta();
				carrito.add(productos);
				//System.out.print("cant " + productos.getCantidad());
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String fechaComoCadena = sdf.format(new Date());
			nuevaVentas.setFecha(fechaComoCadena);
			
			nuevaVentas.setTotalVenta(totalVenta);
			nuevaVentas.setProductos(carrito);
			
			ventasDao.nuevaVentas(nuevaVentas);
			
			//System.out.print(" asaa"+ nuevaVentas.getIdVenta());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void actualizarRegistro() {
		Ventas ventas = new Ventas();
		Map<String, Integer> mapVentas=new HashMap<>();
		mapVentas.put("idDireccion", 1);
		System.out.println("actualizar registro");
		try {
			ventas.setIdVenta(2);
			ventas.setClienteId(7);
			ventas.setTotalVenta(1500.50);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String fechaComoCadena = sdf.format(new Date());
			ventas.setFecha(fechaComoCadena);
			
			ventasDao.actualizarVentas(ventas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Test
	@Ignore
	public void eliminarVentas() {
		
		Map<String, Integer> mapVentas = new HashMap<>();
		mapVentas.put("idVenta", 3);
		System.out.println("Eliminar ");
		try {
			ventasDao.eliminarVentas(mapVentas);
						
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}	

}
