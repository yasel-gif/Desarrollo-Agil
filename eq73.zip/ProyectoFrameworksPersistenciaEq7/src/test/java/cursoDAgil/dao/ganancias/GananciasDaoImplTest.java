package cursoDAgil.dao.ganancias;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Ganancias;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class GananciasDaoImplTest {
	@Inject
	GananciasDao gananciasDao;
	
	

	//@Test
	//@Ignore
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas los Ganancias");
		try {
			List<Ganancias> list = gananciasDao.obtenerGanancias();
			reg = list.size();
			
			for(Ganancias g:list) {
				System.out.println("Id: " + g.getIdGanancia());	
				System.out.println("Nombre: " + g.getVentaId() );
				System.out.println("IdDireccion: " + g.getTotalGanancia());
				System.out.println("fecha: " + g.getFecha());
				
			}
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	@Test
	//@Ignore
	public void nuevoRegistro() {
		Ganancias ganancias = new Ganancias();
		System.out.println("Test nuevo registro");
		try {
			ganancias.setVentaId(1);
			ganancias.setTotalGanancia(55500.0);
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String fechaComoCadena = sdf.format(new Date());
			ganancias.setFecha(fechaComoCadena);
			
			
			gananciasDao.nuevaGanancias(ganancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void consultarVentasPorId() {
		Ganancias ganancias = new Ganancias();
		Map<String, Integer> mapGanancias = new HashMap<>();
		mapGanancias.put("idGanancia", 2);
		try {
			ganancias = gananciasDao.obtenerGananciasPorId(mapGanancias);
			assertNotNull(ganancias);
			System.out.println("id:" + ganancias.getIdGanancia());
			System.out.println("venta id:" + ganancias.getVentaId());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Ignore
	@Test
		public void consultarVentasPorFecha() {
			//Ganancias ganancias = new Ganancias();
			int reg;
			Map<String, String> mapGanancias = new HashMap<>();
			mapGanancias.put("fecha", "2021-04-24");
			try {
				List<Ganancias> list = gananciasDao.obtenerGananciasPorFecha(mapGanancias);
				reg=list.size();	
				for(Ganancias g:list) {	
					System.out.println("id:" + g.getIdGanancia());
					System.out.println("venta id:" + g.getVentaId());
				}
				assertEquals(list.size(), reg);
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
	//@Test
	@Ignore
		public void actualizarRegistro() {
			Ganancias ganancias = new Ganancias();
			Map<String, Integer> mapGanancias=new HashMap<>();
			mapGanancias.put("idDireccion", 1);
			System.out.println("actualizar registro");
			try {
				ganancias.setIdGanancia(1);
				ganancias.setVentaId(1);
				ganancias.setTotalGanancia(100.0);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
				String fechaComoCadena = sdf.format(new Date());
				ganancias.setFecha(fechaComoCadena);
				
				gananciasDao.actualizarGanancias(ganancias);
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
		//@Test
		@Ignore
		public void eliminarGanancias() {
			
			Map<String, Integer> mapGanancias = new HashMap<>();
			mapGanancias.put("idGanancia", 3);
			System.out.println("Eliminar ");
			try {
				gananciasDao.eliminarGanancias(mapGanancias);
				
				
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}	
}
