package cursoDAgil.dao.direccion;

import static org.junit.Assert.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Direccion;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class DireccionDaoImplTest {
	
	@Inject
	DireccionDao direccionDao;

	//@Test
	@Ignore
	public void consultarDireccionPorId() {
		Direccion direccion = new Direccion();
		Map<String, Integer> mapDireccion = new HashMap<>();
		mapDireccion.put("idDireccion", 3);
		try {
			direccion = direccionDao.obtenerDireccionPorId(mapDireccion);
			assertNotNull(direccion);
			System.out.println("id:" + direccion.getIdDireccion());
			System.out.println("calle:" + direccion.getCalle());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas las direcciones");
		try {
			List<Direccion> list = direccionDao.obtenerDirecciones();
			reg = list.size();
			
			for(Direccion d:list) {
				System.out.println("Id: " + d.getIdDireccion());
				System.out.println("Calle : " + d.getCalle());
				System.out.println("Numero : " + d.getNumero());
				
				
			}
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}

	@Ignore
	//@Test
	public void nuevoRegistro() {
		Direccion direccion = new Direccion();
		System.out.println("Test nuevo registro");
		try {
			direccion.setCalle("Micaela Galindo");
			direccion.setNumero(3);
			direccion.setColonia("Centro");
			direccion.setCiudad("Huajuapan");
			direccion.setEstado("Oaxaca");
			direccion.setPais("Mexico");
			direccion.setCodigoPostal(69000);
			direccionDao.nuevaDireccionCliente(direccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Test
	@Ignore
	public void actualizarRegistro() {
		Direccion direccion = new Direccion();
		Map<String, Integer> mapDireccion=new HashMap<>();
		mapDireccion.put("idDireccion", 1);
		try {
			direccion.setIdDireccion(1);
			direccion.setCalle("10 de Abril");
			direccion.setNumero(10);
			direccion.setColonia("Acatlima");
			direccion.setCiudad("Huajuapan");
			direccion.setEstado("Oaxaca");
			direccion.setPais("Mexico");
			direccion.setCodigoPostal(9700);
			
			
			direccionDao.actualizarDireccion(direccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Test
	//@Ignore
	public void eliminarDireccion(){
		System.out.println("Test eliminar registro");
		Map<String, Integer> mapDireccion=new HashMap<>();
		mapDireccion.put("idDireccion", 1);
		System.out.println("//------------------------------------");
		try{
			direccionDao.eliminarDireccion(mapDireccion);
		}catch (Exception e) {
				System.out.println("Error" + e);
		}
	}
}