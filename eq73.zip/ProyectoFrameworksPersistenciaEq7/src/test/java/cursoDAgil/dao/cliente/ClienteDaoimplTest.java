package cursoDAgil.dao.cliente;

import static org.junit.Assert.*;

import javax.inject.Inject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.domain.Direccion;
import cursoDAgil.dao.direccion.DireccionDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class ClienteDaoimplTest {
	@Inject
	ClienteDao clienteDao;
	@Inject
	DireccionDao direccionDao;
	//@Test
	@Ignore
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todos los clientes" );
		try {
			List<Cliente> list = clienteDao.listarTodosClientes();
			reg = list.size();
			
			for(Cliente c:list) {
				System.out.println("Id: " + c.getId());	
				System.out.println("Nombre: " + c.getNombre() );
				System.out.println("Calle: " + c.getDireccion().getCalle() );
				
				
			}
			
			assertEquals(list.size(), reg);
		}catch(Exception ex) {
			System.out.println("Error" + ex);
		}
	}
	//@Test
	@Ignore
	public void consultarClientePorId() {
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 6);
		try {
			cliente = clienteDao.obtenerClientePorId(mapCliente);
			assertNotNull(cliente);
			System.out.println("id:" + cliente.getId());
			System.out.println("nombre:" + cliente.getNombre());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	
	}
	//@Test
	@Ignore
	public void actualizarRegistro() {
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente=new HashMap<>();
		mapCliente.put("idCliente", 1);
		System.out.println("actualizar registro");
		try {
			cliente.setId(1);
			cliente.setNombre("Ana");
			cliente.setApellido("Gonzalez");
			cliente.setEmail("");
			cliente.setSexo("F");
			cliente.setIdDireccion(1);
			
			clienteDao.actualizarCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Test
	@Ignore
	public void eliminarCliente() {
		
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 8);
		System.out.println("Eliminar ");
		try {
			clienteDao.eliminarCliente(mapCliente);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Test
	//@Ignore
	public void nuevoRegistro() {
		Cliente cliente = new Cliente();
		Direccion direccion= new Direccion();
		Map<String, Integer> mapDireccion= new HashMap<>();
		mapDireccion.put("idDireccion",1);
		System.out.println("Test nuevo registro");
		try {
			
			cliente.setNombre("Daniela");
			cliente.setApellido("Zurita");
			cliente.setEmail("dani@gmail.com");
			cliente.setSexo("F");
			direccion= direccionDao.obtenerDireccionPorId(mapDireccion);
			cliente.setIdDireccion(direccion.getIdDireccion());
			cliente.setDireccion(direccion);
			
			
			clienteDao.nuevoCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
}
