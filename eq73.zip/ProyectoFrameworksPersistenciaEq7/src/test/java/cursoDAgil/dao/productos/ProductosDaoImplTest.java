package cursoDAgil.dao.productos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;

import javax.inject.Inject;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Productos;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class ProductosDaoImplTest {
	@Inject
	ProductosDao productosDao;
	
	@Test
	//@Ignore
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas los productos");
		try {
			List<Productos> list = productosDao.obtenerProductos();
			reg = list.size();
			
			for(Productos p:list) {
				System.out.println("Id: " + p.getIdProducto());	
				System.out.println("Nombre: " + p.getNombre() );
				System.out.println("Marca: " + p.getMarcas().getNombreMarca());
				
			}
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	
	@Test
	//@Ignore
	public void consultarProductosPorId() {
		Productos productos = new Productos();
		Map<String, Integer> mapProductos = new HashMap<>();
		mapProductos.put("idProducto", 2);
		try {
			productos = productosDao.obtenerProductosPorId(mapProductos);
			assertNotNull(productos);
			System.out.println("id:" + productos.getIdProducto());
			System.out.println("nombre:" + productos.getNombre());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	//@Test
	@Ignore
	public void eliminarProductos() {
		
		Map<String, Integer> mapProductos = new HashMap<>();
		mapProductos.put("idProducto", 3);
		System.out.println("Eliminar ");
		try {
			productosDao.eliminarProductos(mapProductos);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Test
	//@Ignore
	public void nuevoRegistro() {
		Productos productos = new Productos();
		System.out.println("Test nuevo registro");
		try {
			productos.setNombre("Donitas");
			productos.setPrecio(10.0);
			productos.setPrecioVta(16.0);
			productos.setCantidad(500);
			productos.setMarcaId(1);
			
			productosDao.nuevoProductos(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Ignore
	@Test
	public void actualizarRegistro() {
		Productos productos = new Productos();
		Map<String, Integer> mapProductos=new HashMap<>();
		mapProductos.put("idDireccion", 1);
		System.out.println("actualizar registro");
		try {
			productos.setIdProducto(4);
			productos.setNombre("Takis");
			productos.setPrecio(11.0);
			productos.setPrecioVta(16.0);
			productos.setCantidad(100);
			productos.setMarcaId(1);
			
			productosDao.actualizarProductos(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

}
