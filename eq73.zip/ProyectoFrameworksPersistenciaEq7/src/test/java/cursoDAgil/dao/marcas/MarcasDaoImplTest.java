package cursoDAgil.dao.marcas;
import static org.junit.Assert.*;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import cursoDAgil.bd.domain.Marcas;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class MarcasDaoImplTest {
	@Inject
	MarcasDao marcasDao;
	@Ignore
	//@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas las marcas");
		try {
			List<Marcas> list = marcasDao.obtenerMarcas();
			reg = list.size();
			for(Marcas m:list) {
				System.out.println("Id: " + m.getIdMarca() );
				System.out.println("Id: " + m.getNombreMarca() );
			}
			
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	//@Test
	@Ignore
	public void nuevoRegistro() {
		Marcas marcas = new Marcas();
		System.out.println("Test nuevo registro");
		try {
			marcas.setNombreMarca("Bimbo");
			
			
			marcasDao.nuevaMarcas(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void consultarMarcasPorId() {
		Marcas marcas = new Marcas();
		Map<String, Integer> mapMarcas = new HashMap<>();
		mapMarcas.put("idMarca", 2);
		try {
			marcas = marcasDao.obtenerMarcasPorId(mapMarcas);
			assertNotNull(marcas);
			System.out.println("id:" + marcas.getIdMarca());
			System.out.println("Nombre Marca:" + marcas.getNombreMarca());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void actualizarRegistro() {
		Marcas marcas = new Marcas();
		Map<String, Integer> mapMarcas=new HashMap<>();
		mapMarcas.put("idDireccion", 1);
		System.out.println("actualizar registro");
		try {
			marcas.setIdMarca(1);
			marcas.setNombreMarca("Barcel");
			
			marcasDao.actualizarMarcas(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Test
	//@Ignore
	public void eliminarMarcas() {
		
		Map<String, Integer> mapMarcas = new HashMap<>();
		mapMarcas.put("idMarca", 20);
		System.out.println("Eliminar ");
		try {
			marcasDao.eliminarMarcas(mapMarcas);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}	
}
