package cursoDAgil.dao.ventas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Ventas;

public interface VentasDao {
	List<Ventas> obtenerVentas();
	Ventas obtenerVentas2(Map<String, Integer> mapVentas);
	void nuevaVentas(Ventas ventas);
	Ventas obtenerVentasPorId(Map<String, Integer> mapVentas);
	Integer eliminarVentas(Map<String, Integer> mapVentas);
	Integer actualizarVentas(Ventas Ventas);

}
