package cursoDAgil.dao.ventas;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.domain.Ventas;

import cursoDAgil.bd.mappers.VentasMapper;
import cursoDAgil.dao.detalleVentas.DetalleVentasDao;
import cursoDAgil.dao.ganancias.GananciasDao;
import cursoDAgil.dao.productos.ProductosDao;

@Named
public class VentasDaoImpl  implements VentasDao, Serializable {
	
	private static final long serialVersionUID = 1170013994205021273L;
	SqlSession sqlSession;
	
	
	@Inject
	DetalleVentasDao detalleVentasDao;
	
	@Inject
	ProductosDao productosDao;
	
	@Inject
	GananciasDao gananciasDao;
	
	@Autowired
	/**
	 * @param sqlSession the sqlSession to set
	 */
	public  void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}	
	
	@Transactional
	@Override
	public void nuevaVentas(Ventas ventas) {
		try {
			//int bandera =1;
			Double ganancia=0.0;
			Double gananciant=0.0;
			Double ventTotal=0.0;
			Double ventTotalAnt=0.0;
			//Integer cantidadant=0;
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);
			ventasMapper.nuevaVentas(ventas);
			
			//despues de crear el registro se obtiene el id
			
			
			Integer idVenta=ventas.getIdVenta();//erorr
			//System.out.print("id :"+ ventas.getClienteId() );
			List<Productos> productos = ventas.getProductos();
			Ganancias nGanancias= new Ganancias();
			nGanancias.setVentaId(idVenta);
			for(Productos prod: productos) {
				gananciant=ganancia;
				ventTotalAnt=ventTotal;
				DetalleVentas detalleVentas = new DetalleVentas();
				detalleVentas.setVentaId(idVenta);
				detalleVentas.setProductoId(prod.getIdProducto());
				detalleVentas.setCantidad(prod.getCantidad());
				Productos productoExistente= new Productos();
				
				Map<String, Integer> mapVentas = new HashMap<>();
				mapVentas.put("idProducto", prod.getIdProducto());
				
				productoExistente=productosDao.obtenerProductosPorId(mapVentas);
				
				ventTotal+=prod.getCantidad()*prod.getPrecioVta();
				//System.out.print("vet: "+ventTotal+"\n");
				//cantidadant=productoExistente.getCantidad();
				productoExistente.setCantidad(productoExistente.getCantidad()-prod.getCantidad());
				ganancia+=prod.getCantidad()*(prod.getPrecioVta()-prod.getPrecio());
				//System.out.print("cantidad :" + prod.getCantidad() );
				if(productoExistente.getCantidad()>=0) {
					ventas.setTotalVenta(ventTotal);
					detalleVentasDao.nuevaDetalleVentas(detalleVentas);
					productosDao.actualizarProductos(productoExistente);
					

					//System.out.println("Ventas actualizado con �xito");
					
					
				}
				else {
					ganancia=gananciant;
					ventTotal=ventTotalAnt;
					
				}
				
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String fechaComoCadena = sdf.format(new Date());
			nGanancias.setTotalGanancia(ganancia);
			nGanancias.setFecha(fechaComoCadena);
			gananciasDao.nuevaGanancias(nGanancias);
			ventasMapper.actualizarVentas(ventas);
			System.out.print("luststss");
			//return ventasMapper.nuevaVentas(ventas);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		
	}

	@Override
	public Ventas obtenerVentasPorId(Map<String, Integer> mapVentas) {

		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);

			return ventasMapper.obtenerVentasPorId(mapVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Ventas> obtenerVentas() {
		
		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);
			return ventasMapper.obtenerVentas();
		}
		catch (Exception e){
			System.out.println("Error : " + e);			
		}
		return null;
	}
public Ventas obtenerVentas2(Map<String, Integer> mapVentas) {
		
		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);
			return ventasMapper.obtenerVentas2(mapVentas);
		}
		catch (Exception e){
			System.out.println("Error : " + e);			
		}
		return null;
	}
	@Override
	public Integer actualizarVentas(Ventas ventas) {
		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);
			
			//System.out.print("\n nombre"+ventas.getCliente().getNombre()+ " "+ ventas.getCliente().getApellido()+ "\n");
			System.out.println("Ventas actualizado con exito\n");
			return ventasMapper.actualizarVentas(ventas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarVentas(Map<String, Integer> mapVentas) {
		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);

			System.out.println("Ventas eliminado con �xito");
			return ventasMapper.eliminarVentas(mapVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

}
