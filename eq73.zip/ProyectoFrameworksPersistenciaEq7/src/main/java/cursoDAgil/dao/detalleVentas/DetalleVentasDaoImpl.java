package cursoDAgil.dao.detalleVentas;

import java.util.List;
import java.io.Serializable;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.mappers.DetalleVentasMapper;

@Named
public class DetalleVentasDaoImpl implements DetalleVentasDao, Serializable {
	
	private static final long serialVersionUID = 1170013994205021273L;
	SqlSession sqlSession;
	
	@Autowired
	/**
	 * @param sqlSession the sqlSession to set
	 */
	public  void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	
	@Override
	public Integer nuevaDetalleVentas(DetalleVentas DetalleVentas) {
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);

			System.out.println("detalles ventas  creado con �xito");
			return detalleVentasMapper.nuevaDetalleVentas(DetalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public List<DetalleVentas> obtenerDetalleVentasPorId(Map<String, Integer> mapDetalleVentas) {

		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);
			System.out.println("detalles ventas  por ID");

			return detalleVentasMapper.obtenerDetalleVentasPorId(mapDetalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<DetalleVentas> obtenerDetalleVentas() {
		
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);
			
			return detalleVentasMapper.obtenerDetalleVentas(); 
		}
		catch (Exception e){
			System.out.println("Error : " + e);			
		}
		
		return null;
	
		
	}
	@Override
	public Integer actualizarDetalleVentas(DetalleVentas detalleVentas) {
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);

			System.out.println("DetalleVentas actualizado con �xito");
			return detalleVentasMapper.actualizarDetalleVentas(detalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarDetalleVentas(Map<String, Integer> mapDetalleVentas) {
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);

			System.out.println("DetalleVentas eliminado con �xito");
			return detalleVentasMapper.eliminarDetalleVentas(mapDetalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	
	
}
