package cursoDAgil.dao.marcas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.bd.mappers.MarcasMapper;

@Named
public class MarcasDaoImpl implements MarcasDao, Serializable {
	
	private static final long serialVersionUID = 1170013994205021273L;
	SqlSession sqlSession;
	
	@Autowired
	/**
	 * @param sqlSession the sqlSession to set
	 */
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	@Override
	public Integer nuevaMarcas(Marcas marcas) {
		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);

			System.out.println("Marca creada con �xito");
			return marcasMapper.nuevaMarcas(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	

	@Override
	public Marcas obtenerMarcasPorId(Map<String, Integer> mapMarcas) {

		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);

			return marcasMapper.obtenerMarcasPorId(mapMarcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Marcas> obtenerMarcas() {
		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);

			return marcasMapper.obtenerMarcas();
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer actualizarMarcas(Marcas marcas) {
		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);

			System.out.println("Marcas actualizado con �xito");
			return marcasMapper.actualizarMarcas(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarMarcas(Map<String, Integer> mapMarcas) {
		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);

			System.out.println("Marcas eliminado con exito");
			return marcasMapper.eliminarMarcas(mapMarcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}