package cursoDAgil.dao.cliente;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.mappers.ClienteMapper;
@Named
public class ClienteDaoImpl implements Serializable, ClienteDao {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1170013994205021273L;
	SqlSession sqlSession;
	
	@Autowired
	/**
	 * @param sqlSession the sqlSession to set
	 */
	public  void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	@Override
	public List<Cliente> listarTodosClientes() {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.listarTodosClientes();
		}
		catch (Exception e){
			System.out.println("Error : " + e);			
		}
		return null;
	}
	@Override
	public Cliente obtenerClientePorId(Map<String, Integer> mapCliente) {

		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);

			return clienteMapper.obtenerClientePorId(mapCliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer actualizarCliente(Cliente cliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);

			System.out.println("Cliente actualizado con exito");
			return clienteMapper.actualizarCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarCliente(Map<String, Integer> mapCliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);

			System.out.println("Cliente eliminado con exito");
			return clienteMapper.eliminarCliente(mapCliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer nuevoCliente(Cliente cliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);

			System.out.println("cliente creado con exito");
			return clienteMapper.nuevoCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}
