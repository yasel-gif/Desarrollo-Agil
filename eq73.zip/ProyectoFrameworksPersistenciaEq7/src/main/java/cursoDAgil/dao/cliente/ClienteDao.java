package cursoDAgil.dao.cliente;
import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Cliente;




public interface ClienteDao {
	List <Cliente> listarTodosClientes();
	Cliente obtenerClientePorId(Map<String, Integer> mapCliente);
	Integer actualizarCliente(Cliente cliente);
	Integer eliminarCliente(Map<String, Integer> mapCliente);
	Integer nuevoCliente(Cliente cliente);
}
