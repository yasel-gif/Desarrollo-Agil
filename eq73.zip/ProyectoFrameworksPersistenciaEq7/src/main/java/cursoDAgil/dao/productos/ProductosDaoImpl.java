package cursoDAgil.dao.productos;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;


import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.mappers.ProductosMapper;

@Named
public class ProductosDaoImpl  implements ProductosDao, Serializable {
	
	private static final long serialVersionUID = 1170013994205021273L;
	SqlSession sqlSession;
	
	@Autowired
	/**
	 * @param sqlSession the sqlSession to set
	 */
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public Integer nuevoProductos(Productos productos) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);

			System.out.println("Producto creado con �xito");
			return productosMapper.nuevoProductos(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarProductos(Map<String, Integer> mapProductos) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);

			System.out.println("Producto eliminado con �xito");
			return productosMapper.eliminarProductos(mapProductos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Productos obtenerProductosPorId(Map<String, Integer> mapProductos) {

		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			

			return productosMapper.obtenerProductosPorId(mapProductos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Productos> obtenerProductos() {
		
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			
			return productosMapper.obtenerProductos();
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	
	@Override
	public Integer actualizarProductos(Productos productos) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);

			System.out.println("Productos actualizado con �xito");
			return productosMapper.actualizarProductos(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}
