package cursoDAgil.dao.ganancias;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.bd.mappers.GananciasMapper;

@Named


public class GananciasDaoImpl implements GananciasDao,Serializable {
	
	private static final long serialVersionUID = 1170013994205021273L;
	SqlSession sqlSession;
	
	@Autowired
	/**
	 * @param sqlSession the sqlSession to set
	 */
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	@Override
	public Integer nuevaGanancias(Ganancias ganancias) {
		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);

			System.out.println("Ganancia creada con �xito");
			return gananciasMapper.nuevaGanancias(ganancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Ganancias obtenerGananciasPorId(Map<String, Integer> mapGanancias) {

		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);

			return gananciasMapper.obtenerGananciasPorId(mapGanancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public List<Ganancias> obtenerGananciasPorFecha(Map<String, String> mapGanancias) {

		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);

			return gananciasMapper.obtenerGananciasPorFecha(mapGanancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public List<Ganancias> obtenerGanancias() {
		
		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);
			
			return gananciasMapper.obtenerGanancias();
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer actualizarGanancias(Ganancias ganancias) {
		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);

			System.out.println("Ganancias actualizado con �xito");
			return gananciasMapper.actualizarGanancias(ganancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarGanancias(Map<String, Integer> mapGanancias) {
		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);

			System.out.println("Ganancias eliminado con �xito");
			return gananciasMapper.eliminarGanancias(mapGanancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}


}
