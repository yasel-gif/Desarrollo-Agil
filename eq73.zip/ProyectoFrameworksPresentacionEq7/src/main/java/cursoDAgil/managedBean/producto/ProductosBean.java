package cursoDAgil.managedBean.producto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.service.productos.ProductosService;

@Named
@ViewScoped
public class ProductosBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	ProductosService productosService;

	private List<Productos> listaProductos;
	private Productos productos;
	private List<Productos> blistaProductos;
	
	@PostConstruct
	public void init() {
		if (listaProductos == null)
			listaProductos = new ArrayList<Productos>();
		if (productos == null) {
			productos = new Productos();
			productos.setMarcas(null);
		}
		// se invoca el metodo del servicio para obtener los productos

		// con su Marca
		setlistaProductos(productosService.obtenerProductos());

	}

	// metodo que registra nuevo productos
	public void registrar() {
		// invocar al servicio
		productosService.nuevoProductos(getProductos());

		// limpia los valores del objeto
		setProductos(new Productos());

		// se actualiza los valores de la tabla
		setlistaProductos(productosService.obtenerProductos());

		getlistaProductos();
		FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));

	}

	public void deleteSelected(Productos pro) {

		
		Map<String, Integer> mapProductos = new HashMap<>();
		mapProductos.put("idProducto", pro.getIdProducto());
		if(productosService.eliminarProductos(mapProductos) != null){
			setlistaProductos(productosService.obtenerProductos());
			getlistaProductos();
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete exitoso!"));
		}else{
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete ha fallado!"));
		}		// se actualiza los valores de la tabla
		

	}

	public void onRowEdit(RowEditEvent event) {
		Productos pro = ((Productos) event.getObject());
		pro.setMarcas(productos.getMarcas());
		productosService.actualizarProductos(pro);
		FacesMessage msg = new FacesMessage("productos editado", pro.getIdProducto().toString());

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edicion cancelada",
				((Productos) event.getObject()).getIdProducto().toString());

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		System.out.println("verifica: " + newValue);
		if (newValue != null && !newValue.equals(oldValue)) {
			FacesMessage msg = new

			FacesMessage(FacesMessage.SEVERITY_INFO, "produto modificado",
					"Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	// setters y getters
	public Productos getProductos() {
		return productos;
	}

	public void setProductos(Productos productos) {
		this.productos = productos;
	}

	public List<Productos> getlistaProductos() {
		return listaProductos;
	}

	public void setlistaProductos(List<Productos> listaProductos) {
		this.listaProductos = listaProductos;
	}

	public List<Productos> getBlistaProductos() {
		return blistaProductos;
	}

	public void setBlistaProductos(List<Productos> blistaProductos) {
		this.blistaProductos = blistaProductos;
	}

	

	
}
