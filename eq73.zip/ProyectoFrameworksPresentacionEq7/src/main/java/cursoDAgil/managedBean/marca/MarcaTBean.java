package cursoDAgil.managedBean.marca;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;


import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.service.marcas.MarcasService;

@Named
@ViewScoped
public class MarcaTBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1558L;

	@Inject
	MarcasService marcasService;

	private List<Marcas> listaMarcas;
	private List<Marcas> blistaMarcas;
	private Marcas marcas;

	@PostConstruct
	public void init() {

		if (listaMarcas == null)
			listaMarcas = new ArrayList<Marcas>();
		if (marcas == null)
			marcas = new Marcas();

		setlistaMarcas(marcasService.obtenerMarcas());
	}

	// metodo que registra nuevo Marcas
	public void registrar() {
		// invocar al servicio
		
		if(marcasService.nuevaMarcas(getMarcas()) != null){
			// limpia los valores del objeto
			setMarcas(new Marcas());

			// se actualiza los valores de la tabla
			setlistaMarcas(marcasService.obtenerMarcas());

			// setlistaMarcas(MarcasService.findAllDireccions());
			getListaMarcas();
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));
		}else{
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro ha fallado!"));
		}
		

		

	}

	public Marcas getMarcas() {
		return marcas;
	}

	public void setMarcas(Marcas marcas) {
		this.marcas = marcas;
	}

	public List<Marcas> getListaMarcas() {
		return listaMarcas;
	}

	public void setlistaMarcas(List<Marcas> listaMarcas) {

		this.listaMarcas = listaMarcas;
	}

	public void deleteSelected(Marcas mar) {

		System.out.print(mar.getIdMarca() + " xx\n ");
		Map<String, Integer> mapMarcas = new HashMap<>();
		mapMarcas.put("idMarca", mar.getIdMarca());
		if(marcasService.eliminarMarcas(mapMarcas) != null){
			// se actualiza los valores de la tabla
			setlistaMarcas(marcasService.obtenerMarcas());
			getListaMarcas();
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete exitoso!"));
		}else{
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete ha fallado!"));
		}
		

	}

	public void onRowEdit(RowEditEvent event) {
		Marcas marcas = ((Marcas) event.getObject());
		System.out.println("datos marcas: " + marcas.getIdMarca());
		marcasService.actualizarMarcas(marcas);
		FacesMessage msg = new FacesMessage("Marcas editado", marcas.getIdMarca().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edicion cancelada", ((Marcas) event.getObject()).getIdMarca().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();

		System.out.println("verrifica: " + newValue);
		if (newValue != null & !newValue.equals(oldValue)) {
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Marcas modificado",
					"Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public List<Marcas> getBlistaMarcas() {
		return blistaMarcas;
	}

	public void setBlistaMarcas(List<Marcas> blistaMarcas) {
		this.blistaMarcas = blistaMarcas;
	}

}