package cursoDAgil.managedBean.ganancias;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.service.ganancias.GananciasService;

@Named
@ViewScoped
public class GananciasBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	GananciasService gananciasService;
	
	private List<Ganancias> listaGanancias;
	private List<Ganancias> blistaGanancias;

	private Ganancias ganancias;

	@PostConstruct
	public void init() {
		if (listaGanancias == null)
			listaGanancias = new ArrayList<Ganancias>();
		if (ganancias == null) {
			ganancias = new Ganancias();
			ganancias.setVentas(null);
			
		}
		
		setlistaGanancias(gananciasService.obtenerGanancias());
		
	}

	// metodo que registra nuevo ganancia
	public void registrar() {
		// invocar al servicio
		gananciasService.nuevaGanancias(getGanancias());
		//System.out.print("asdsadasd");
		// limpia los valores del objeto
		setGanancias(new Ganancias());
		
		// se actualiza los valores de la tabla
		setlistaGanancias(gananciasService.obtenerGanancias());
		
		
		getlistaGanancias();
		FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));

	}

	public void onRowEdit(RowEditEvent event) {
		Ganancias gan = ((Ganancias) event.getObject());
		gan.setVentas(ganancias.getVentas());
		gananciasService.actualizarGanancias(gan);
		FacesMessage msg = new FacesMessage("Ganancias editado",gan.getIdGanancia().toString());

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}
	
	public void deleteSelected(Ganancias gan) {
		
		
		System.out.print(gan.getIdGanancia()+" xx\n ");
		Map<String, Integer> mapGanancias = new HashMap<>();
		mapGanancias.put("idGanancia", gan.getIdGanancia());
		if(gananciasService.eliminarGanancias(mapGanancias) != null){
			// se actualiza los valores de la tabla
			setlistaGanancias(gananciasService.obtenerGanancias());
			getlistaGanancias();
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete exitoso!"));
		}else{FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete ha fallado!"));}
		
        
    }
	

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edicion cancelada",((Ganancias) event.getObject()).getIdGanancia().toString());

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		System.out.println("verifica: " + newValue);
		if (newValue != null && !newValue.equals(oldValue)) {
			FacesMessage msg = new

			FacesMessage(FacesMessage.SEVERITY_INFO, "ganancias modificado", "Antes: " + oldValue + ", Ahora: " +newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	// setters y getters
	public Ganancias getGanancias() {
		return ganancias;
	}

	public void setGanancias(Ganancias ganancias) {
		this.ganancias = ganancias;
	}

	public List<Ganancias> getlistaGanancias() {
		return listaGanancias;
	}

	public void setlistaGanancias(List<Ganancias> listaGanacias) {
		this.listaGanancias = listaGanacias;
	}

	public List<Ganancias> getBlistaGanancias() {
		return blistaGanancias;
	}

	public void setBlistaGanancias(List<Ganancias> blistaGanancias) {
		this.blistaGanancias = blistaGanancias;
	}
}
