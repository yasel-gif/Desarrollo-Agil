package cursoDAgil.managedBean.direccion;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Direccion;

import cursoDAgil.service.direccion.DireccionService;

@Named
@ViewScoped
public class DireccionTBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	DireccionService direccionService;

	private List<Direccion> listaDireccion;
	private Direccion direccion;
	private List<Direccion> blistaDireccion;

	@PostConstruct
	public void init() {
		if (listaDireccion == null)
			listaDireccion = new ArrayList<Direccion>();
		if (direccion == null)
			direccion = new Direccion();
		setlistaDireccion(direccionService.obtenerDirecciones());
	}

	// metodo que registra nuevo Direccion
	public void registrar() {
		// invocar al servicio
		direccionService.nuevaDireccionCliente(getDireccion());

		// limpia los valores del objeto
		setDireccion(new Direccion());

		// se actualiza los valores de la tabla
		setlistaDireccion(direccionService.obtenerDirecciones());

		// setlistaDireccion(DireccionService.findAllDireccions());
		getListaDireccion();
		FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));

	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public List<Direccion> getListaDireccion() {
		return listaDireccion;
	}

	public void setlistaDireccion(List<Direccion> listaDireccion) {
		this.listaDireccion = listaDireccion;
	}

	public void deleteSelected(Direccion dir) {

		Map<String, Integer> mapDireccion = new HashMap<>();
		mapDireccion.put("idDireccion", dir.getIdDireccion());
		
		if(direccionService.eliminarDireccion(mapDireccion) != null){
			setlistaDireccion(direccionService.obtenerDirecciones());
			getListaDireccion();
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete exitoso!"));
			System.out.println("//------------------------------------");
		
		}else{
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Delete ha fallado!"));
		}
			
		
			
		
		

	}

	public void onRowEdit(RowEditEvent event) {
		Direccion direccion = ((Direccion) event.getObject());
		System.out.println("datos direccion: " + direccion.getIdDireccion());
		
		direccionService.actualizarDireccion(direccion);
		
		FacesMessage msg = new FacesMessage("Direccion editado", direccion.getIdDireccion().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edicion cancelada",
				((Direccion) event.getObject()).getIdDireccion().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();

		System.out.println("verrifica: " + newValue);
		if (newValue != null & !newValue.equals(oldValue)) {
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "!Direccion modificado",
					"Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public List<Direccion> getBlistaDireccion() {
		return blistaDireccion;
	}

	public void setBlistaDireccion(List<Direccion> blistaDireccion) {
		this.blistaDireccion = blistaDireccion;
	}


}