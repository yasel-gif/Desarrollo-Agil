package cursoDAgil.managedBean.detalleVentas;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.service.detalleVentas.DetalleVentasService;

@Named
@ViewScoped
public class DetalleVentasBean implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	DetalleVentasService detalleVentasService;
	
	private List<DetalleVentas> listaDetalleVentas;
	private DetalleVentas detalleVentas;
	
	@PostConstruct
	public void init() {
		if (listaDetalleVentas == null)
			listaDetalleVentas = new ArrayList<DetalleVentas>();
		if (detalleVentas == null) 
			detalleVentas = new DetalleVentas();		
		setlistaDetalleVentas(detalleVentasService.obtenerDetalleVentas()); 
	}
	// metodo que registra nuevo DetalleVentas
		public void registrar() {
			// invocar al servicio
			detalleVentasService.nuevaDetalleVentas(getDetalleVentas());
			
			// limpia los valores del objeto
			setDetalleVentas(new DetalleVentas());
			
			// se actualiza los valores de la tabla
			setlistaDetalleVentas(detalleVentasService.obtenerDetalleVentas());
			
			// setlistaDetalleVentas(DireccionService.findAllDireccions());
			getListaDetalleVentas();
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));

		}
	public DetalleVentas getDetalleVentas() {
		return detalleVentas;
	}
	
	public void setDetalleVentas(DetalleVentas detalleVentas) {
		this.detalleVentas = detalleVentas;
	}
	
	public List<DetalleVentas> getListaDetalleVentas() {
		return listaDetalleVentas;
	}

	public void setlistaDetalleVentas(List<DetalleVentas> listaDetalleVentas) {
		this.listaDetalleVentas = listaDetalleVentas;
	}

	public void onRowEdit(RowEditEvent event){
		DetalleVentas detalleVentas = ((DetalleVentas) event.getObject());
		System.out.println("datos detalleVentas: " + detalleVentas.getVentaId());
		detalleVentasService.actualizarDetalleVentas(detalleVentas);
		FacesMessage msg = new FacesMessage("DetalleVentas editado", detalleVentas.getVentaId().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}
	
	public void onRowCancel(RowEditEvent event){
		FacesMessage msg = new FacesMessage("Edicion cancelada", ((DetalleVentas) event.getObject()).getVentaId().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}
	
	public void onCellEdit(CellEditEvent event){
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		
		System.out.println("verrifica: " + newValue);
		if(newValue != null & !newValue.equals(oldValue)){
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "DetalleVentas modificado", "Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}
	
}
