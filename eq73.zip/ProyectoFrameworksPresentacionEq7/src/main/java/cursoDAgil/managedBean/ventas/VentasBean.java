package cursoDAgil.managedBean.ventas;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.service.cliente.ClienteService;
import cursoDAgil.service.productos.ProductosService;
import cursoDAgil.service.ventas.VentasService;

@Named
@ViewScoped
public class VentasBean implements Serializable  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject
	VentasService ventasService;
	@Inject
	ProductosService productoService;
	@Inject 
	ClienteService clienteService;
	
	private List<Ventas> listaVentas;
	private List<Cliente> listaClientes;
	private List<Productos> listaProductos;
	// cuando seleccione un cliente aqui se guarda
	private Cliente cliente;
	// es para generar la venta.
	private Ventas nuevaVenta;
	
	private Ventas venta;
	// para generar la venta
	// primero aqui asigno el producto seleccionado, pido la cantidad
	private Productos producto;
	private Productos temp;
	
	public Productos getTemp() {
		return temp;
	}
	public void setTemp(Productos temp) {
		this.temp = temp;
	}
	private List<Productos> carrito;
	private Double totalVenta;
	
	
	
	/**xxxxxxxxxx/
	
	private List<Ventas> blistaVentas;
	private List<DetalleVentas> listadetalles;
	private Ventas dlistaVentas;
	private Ventas ventas;
	private Ventas ventas2;
	private Integer idDv;
	
	
	xx*/
	
	@PostConstruct
	public void init() {
		if (listaVentas == null)
			listaVentas = new ArrayList<Ventas>();
		if (listaClientes == null)
			listaClientes = new ArrayList<Cliente>();
		if (listaProductos == null)
			listaProductos = new ArrayList<Productos>();
		if (carrito == null)
			carrito = new ArrayList<Productos>();
		if (cliente == null) {
			cliente = new Cliente();
		}
		if (nuevaVenta == null) {
			nuevaVenta= new Ventas();
		}
		if (producto == null) {
			producto = new Productos();
		}
		if (temp == null) {
			temp = new Productos();
		}
		temp.setCantidad(1);
		totalVenta=0.0;
		//setListaClientes(clienteService.listarTodosClientes());
		setListaVentas(ventasService.obtenerVentas());
		
		System.out.println("Listas: "+listaVentas.size());
	
		
	}
	
	
	// metodo que registra nuevo Ventas
			public void registrar() {
				// invocar al servicio
				venta=getVenta();
				venta.setClienteId(1);
				ventasService.nuevaVentas(venta);
				
				// limpia los valores del objeto
				setVenta(new Ventas());
				
				// se actualiza los valores de la tabla
				setListaVentas(ventasService.obtenerVentas());
				
				
				getListaVentas();
				FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));

			}
	public List<Productos>  actualizaListaProductos(){
		setListaProductos(productoService.obtenerProductos());
		return getListaProductos();
    }
    public List<Productos> obtenerDetalles(){
		System.out.println("id venta: "+venta.getIdVenta());
		Map<String, Integer> mapVentas = new HashMap<>();
		mapVentas.put("idVenta",venta.getIdVenta());
		nuevaVenta=ventasService.obtenerVentasPorId(mapVentas);
		System.out.println();
    	return  nuevaVenta.getProductos();
    }
    public void agregarAlCarrito(){
    	boolean esNuevo=true;
    	Productos prod=getProducto();
    	//System.out.println("Producto id: "+prod.getIdProducto());
    	//System.out.println("Producto Nombre: "+prod.getNombre());
    	//System.out.println("Producto cantidad: "+prod.getCantidad());
    	for(Productos product:carrito){
    		if(product.equals(prod)){
    			totalVenta+=temp.getCantidad()+prod.getPrecioVta();
    			product.setCantidad(product.getCantidad()*temp.getCantidad());
    			esNuevo=false;
    			break;
    		}
    	}
    
    	if(esNuevo){
    		producto.setCantidad(temp.getCantidad());
    		totalVenta+=temp.getCantidad()*prod.getPrecioVta();
    		carrito.add(getProducto());
    	}
    	temp.setCantidad(1);

    	
    	System.out.println("------| "+carrito.size() +" : "+totalVenta+":------");
    }
    
    public Ventas getVenta() {
		return venta;
	}

	public void setVenta(Ventas venta) {
		this.venta = venta;
	}
	public List<Ventas> getListaVentas() {
		return listaVentas;
	}
	public void setListaVentas(List<Ventas> listaVentas) {
		this.listaVentas = listaVentas;
	}
	public List<Cliente> getListaClientes() {
		return listaClientes;
	}
	public void setListaClientes(List<Cliente> clientes) {
		this.listaClientes = clientes;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Ventas getNuevaVenta() {
		return nuevaVenta;
	}
	public void setNuevaVenta(Ventas nuevaVenta) {
		this.nuevaVenta = nuevaVenta;
	}
	public Productos getProducto() {
		System.out.println("nombre: "+producto.getNombre());
		System.out.println("Cantidad: "+producto.getCantidad());

		return producto;
	}
	public void setProducto(Productos producto) {
		System.out.println("nombre: "+producto.getNombre());
		System.out.println("Cantidad: "+producto.getCantidad());

		this.producto = producto;
	}
	public List<Productos> getCarrito() {
		return carrito;
	}
	public void setCarrito(List<Productos> carrito) {
		this.carrito = carrito;
	}
	public Double getTotalVenta() {
		return totalVenta;
	}
	public void setTotalVenta(Double totalVenta) {
		this.totalVenta = totalVenta;
	}
	public List<Productos> getListaProductos() {
		return listaProductos;
	}
	public void setListaProductos(List<Productos> listaProductos) {
		this.listaProductos = listaProductos;
	}
	
}
