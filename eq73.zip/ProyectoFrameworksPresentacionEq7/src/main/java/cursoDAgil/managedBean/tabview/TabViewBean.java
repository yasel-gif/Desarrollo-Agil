package cursoDAgil.managedBean.tabview;

import java.io.Serializable;

public class TabViewBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean bandera;

	public boolean isBandera() {
		return bandera;
	}

	public void setBandera(boolean bandera) {
		this.bandera = bandera;
	}

	public TabViewBean() {
		setBandera(true);
	}

}