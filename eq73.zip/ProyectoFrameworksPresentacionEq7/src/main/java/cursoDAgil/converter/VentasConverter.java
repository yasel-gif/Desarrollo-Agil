package cursoDAgil.converter;

import java.util.HashMap;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.service.ventas.VentasService;

@Named
public class VentasConverter implements Converter {
	@Inject
	VentasService ventasService;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		//System.out.print(value+" value ");
		Map<String, Integer> mapVentas = new HashMap<>();
		mapVentas.put("idVenta", Integer.parseInt(value));
		if (value != null && (value.trim().length() > 0)) {
			//System.out.print("\n aa"+ventasService.obtenerVentasPorId(mapVentas).getIdVenta());
			
			return ventasService.obtenerVentasPorId(mapVentas);

		} else {
			return null;
		}
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (((value != null) && ((Ventas) value).getIdVenta()!= null)){
			
			return ((Ventas) value).getIdVenta() .toString();
		} else {
			return null;
		}
	}

}