package cursoDAgil.converter;

import java.util.HashMap;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.service.productos.ProductosService;


@Named
public class ProductosConverter implements Converter {
    @Inject
    ProductosService productosService;
    
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        //System.out.print(value+" value ");
        Map<String, Integer> mapProductos = new HashMap<>();
        mapProductos.put("idProducto", Integer.parseInt(value));
        if (value != null && (value.trim().length() > 0)) {
            System.out.println("--"+productosService.obtenerProductosPorId(mapProductos).getIdProducto());
            return productosService.obtenerProductosPorId(mapProductos);

        } else {
            return null;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
    	 //System.out.print(" value ");
        if (((value != null) && ((Productos) value).getIdProducto()!= null)){
            //System.out.println(((Productos) value).getIdProducto() .toString());
            return ((Productos) value).getIdProducto() .toString();
        } else {
            return null;
		}
	}

}