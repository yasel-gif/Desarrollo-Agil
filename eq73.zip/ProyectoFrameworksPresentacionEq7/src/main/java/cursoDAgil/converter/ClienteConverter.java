package cursoDAgil.converter;



import java.util.HashMap;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.service.cliente.ClienteService;

@Named
public class ClienteConverter implements Converter {
	@Inject
	ClienteService clienteService;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", Integer.parseInt(value));
		
		if (value != null && (value.trim().length() > 0)) {
			System.out.print("\nnn"+clienteService.obtenerClientePorId(mapCliente).getNombre()+"\n");
			return clienteService.obtenerClientePorId(mapCliente);

		} else {
			return null;
		}
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (((value != null) && ((Cliente) value).getId()!= null)){
			//System.out.print("xx "+((Cliente) value).getId().toString());
			
			return ((Cliente) value).getId().toString();
		} else {
			return null;
		}
	}

}