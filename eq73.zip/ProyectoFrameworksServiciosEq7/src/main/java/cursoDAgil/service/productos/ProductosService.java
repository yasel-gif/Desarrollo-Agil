package cursoDAgil.service.productos;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Productos;

public interface ProductosService {

	Integer nuevoProductos(Productos productos);
	Integer eliminarProductos(Map<String, Integer> mapProductos);
	Productos obtenerProductosPorId(Map<String, Integer> mapProductos);
	List<Productos> obtenerProductos();
	Integer actualizarProductos(Productos productos);
}
