package cursoDAgil.service.productos;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.dao.productos.ProductosDao;

@Named
public class ProductosServiceImpl  implements ProductosService, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8372161926007510491L;
	
	@Inject
	ProductosDao productosDao;
	@Override
	public Integer nuevoProductos(Productos productos) {
		return productosDao.nuevoProductos(productos);
		
	}
	@Override
	public Integer eliminarProductos(Map<String, Integer> mapProductos) {
		return productosDao.eliminarProductos(mapProductos);
		
	}
	@Override
	public Productos obtenerProductosPorId(Map<String, Integer> mapProductos) {
		return productosDao.obtenerProductosPorId(mapProductos);
		
	}

	@Override
	public List<Productos> obtenerProductos() {
		
		return productosDao.obtenerProductos();
		
	}
	
	
	@Override
	public Integer actualizarProductos(Productos productos) {
		return productosDao.actualizarProductos(productos);
		
	}

}
