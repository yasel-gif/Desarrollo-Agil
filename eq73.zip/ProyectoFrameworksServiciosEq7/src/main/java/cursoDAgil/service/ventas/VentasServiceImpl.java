package cursoDAgil.service.ventas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.transaction.annotation.Transactional;

import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.dao.ventas.VentasDao;

@Named
public class VentasServiceImpl implements VentasService, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7105141311020707006L;
	
	@Inject
	VentasDao ventasDao;
	@Transactional
	@Override
	public void nuevaVentas(Ventas ventas) {
		ventasDao.nuevaVentas(ventas);	
		
	}

	@Override
	public Ventas obtenerVentasPorId(Map<String, Integer> mapVentas) {

		return ventasDao.obtenerVentasPorId(mapVentas);
		
	}
	@Override
	public Ventas obtenerVentas2(Map<String, Integer> mapVentas) {
		
		return ventasDao.obtenerVentas2(mapVentas);
		
	}
	@Override
	public List<Ventas> obtenerVentas() {
		
		return ventasDao.obtenerVentas();
		
	}
	@Override
	public Integer actualizarVentas(Ventas ventas) {
		return ventasDao.actualizarVentas(ventas);
		
	}
	@Override
	public Integer eliminarVentas(Map<String, Integer> mapVentas) {
		return ventasDao.eliminarVentas(mapVentas);
		
	}
	

}
