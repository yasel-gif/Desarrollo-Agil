package cursoDAgil.service.ganancias;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.dao.ganancias.GananciasDao;

@Named
public class GananciasServiceImpl implements  GananciasService,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6640364817640504101L;
	@Inject
	GananciasDao gananciasDao;
	@Override
	public Integer nuevaGanancias(Ganancias ganancias) {
		return gananciasDao.nuevaGanancias(ganancias);
		
	}

	@Override
	public Ganancias obtenerGananciasPorId(Map<String, Integer> mapGanancias) {

		return gananciasDao.obtenerGananciasPorId(mapGanancias);
		
	}
	@Override
	public List<Ganancias> obtenerGananciasPorFecha(Map<String, String> mapGanancias) {

		return gananciasDao.obtenerGananciasPorFecha(mapGanancias);
		
	}
	@Override
	public List<Ganancias> obtenerGanancias() {
		
		return gananciasDao.obtenerGanancias();
		
	}
	@Override
	public Integer actualizarGanancias(Ganancias ganancias) {
		return gananciasDao.actualizarGanancias(ganancias);
		
	}
	@Override
	public Integer eliminarGanancias(Map<String, Integer> mapGanancias) {
		return gananciasDao.eliminarGanancias(mapGanancias);
		
	}



	
	

}
