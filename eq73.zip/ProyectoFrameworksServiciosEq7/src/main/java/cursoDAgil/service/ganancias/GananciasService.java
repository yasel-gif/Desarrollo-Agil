package cursoDAgil.service.ganancias;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Ganancias;

public interface GananciasService {
	Integer nuevaGanancias(Ganancias ganancias);
	Ganancias obtenerGananciasPorId(Map<String, Integer> mapGanancias);
	List<Ganancias> obtenerGananciasPorFecha(Map<String, String> mapGanancias);
	 List<Ganancias> obtenerGanancias();
	 Integer actualizarGanancias(Ganancias ganancias);
	 Integer eliminarGanancias(Map<String, Integer> mapGanancias);

}
