package cursoDAgil.service.marcas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Marcas;

public interface MarcasService {

	Integer nuevaMarcas(Marcas marcas);
	Marcas obtenerMarcasPorId(Map<String, Integer> mapMarcas);
	List<Marcas> obtenerMarcas();
	Integer actualizarMarcas(Marcas marcas);
	Integer eliminarMarcas(Map<String, Integer> mapMarcas);
}
