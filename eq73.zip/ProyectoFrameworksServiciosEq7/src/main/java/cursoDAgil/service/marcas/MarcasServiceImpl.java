package cursoDAgil.service.marcas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.dao.marcas.MarcasDao;

@Named
public class MarcasServiceImpl implements MarcasService,Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5524857730420840115L;
	
	@Inject
	MarcasDao marcasDao;
	@Override
	public Integer nuevaMarcas(Marcas marcas) {
		return marcasDao.nuevaMarcas(marcas);
		
	}
	

	@Override
	public Marcas obtenerMarcasPorId(Map<String, Integer> mapMarcas) {

		return marcasDao.obtenerMarcasPorId(mapMarcas);
		
	}

	@Override
	public List<Marcas> obtenerMarcas() {
		return marcasDao.obtenerMarcas();
		
	}
	@Override
	public Integer actualizarMarcas(Marcas marcas) {
		return marcasDao.actualizarMarcas(marcas);
		
	}
	@Override
	public Integer eliminarMarcas(Map<String, Integer> mapMarcas) {
		
		return marcasDao.eliminarMarcas(mapMarcas);
	}
	

}
