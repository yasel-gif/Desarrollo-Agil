package cursoDAgil.service.direccion;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Direccion;

public interface DireccionService {
	Integer nuevaDireccionCliente(Direccion direccion);

	Direccion obtenerDireccionPorId(Map<String, Integer> mapDireccion);

	List<Direccion> obtenerDirecciones();

	Integer actualizarDireccion(Direccion direccion);

	Integer eliminarDireccion(Map<String, Integer> mapDireccion);

}
