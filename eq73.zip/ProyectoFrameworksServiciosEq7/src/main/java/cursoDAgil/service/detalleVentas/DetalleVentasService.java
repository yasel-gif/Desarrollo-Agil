package cursoDAgil.service.detalleVentas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.DetalleVentas;

public interface DetalleVentasService {
	Integer nuevaDetalleVentas(DetalleVentas DetalleVentas);
	List<DetalleVentas> obtenerDetalleVentasPorId(Map<String, Integer> mapDetalleVentas);
	List<DetalleVentas> obtenerDetalleVentas();
	Integer actualizarDetalleVentas(DetalleVentas detalleVentas);
	Integer eliminarDetalleVentas(Map<String, Integer> mapDetalleVentas);

}
