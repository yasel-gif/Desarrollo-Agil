package cursoDAgil.service.detalleVentas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.dao.detalleVentas.DetalleVentasDao;


@Named
public class DetalleVentasServiceImpl implements DetalleVentasService, Serializable  {
	
	private static final long serialVersionUID = 6098795555433205360L;
	
	
	@Inject
	DetalleVentasDao detalleVentasDao;
	
	@Override
	public Integer nuevaDetalleVentas(DetalleVentas DetalleVentas) {
		
		return detalleVentasDao.nuevaDetalleVentas(DetalleVentas);
		
	}
	
	@Override
	public List<DetalleVentas> obtenerDetalleVentasPorId(Map<String, Integer> mapDetalleVentas) {

		return detalleVentasDao.obtenerDetalleVentasPorId(mapDetalleVentas);
		
	}

	@Override
	public List<DetalleVentas> obtenerDetalleVentas() {
		
		return detalleVentasDao.obtenerDetalleVentas(); 
		
	}
	@Override
	public Integer actualizarDetalleVentas(DetalleVentas detalleVentas) {
		
		return detalleVentasDao.actualizarDetalleVentas(detalleVentas);
	}
	@Override
	public Integer eliminarDetalleVentas(Map<String, Integer> mapDetalleVentas) {
		
		return detalleVentasDao.eliminarDetalleVentas(mapDetalleVentas);
	}
	
	
}
