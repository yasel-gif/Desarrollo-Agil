package cursoDAgil.service.detalleVentas;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.DetalleVentas;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class DetalleVentasServiceImplTest {
	@Inject
	DetalleVentasService detalleVentasService;

	//@Test
	@Ignore
	public void consultarDetalleVentasPorId() {
		//DetalleVentas detalleVentas = new DetalleVentas();
		Map<String, Integer> mapDetalleVentas = new HashMap<>();
		mapDetalleVentas.put("ventaId", 2);
		try {
			List<DetalleVentas> list = detalleVentasService.obtenerDetalleVentasPorId(mapDetalleVentas);
			for(DetalleVentas d:list) {
				System.out.println("id:" + d.getVentaId());
				System.out.println("produto id:" + d.getProductoId());
			}
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	//@Ignore
	@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas las DetalleVentases");
		try {
			List<DetalleVentas> list = detalleVentasService.obtenerDetalleVentas();
			reg = list.size();
			for (DetalleVentas d : list) {
				System.out.println("Venta Id: " + d.getVentaId());
				System.out.println("total venta: " + d.getVentas().getTotalVenta());
				System.out.println("ProductoId: " + d.getProductoId());
				System.out.println("cantidad: " + d.getCantidad());
				System.out.println("nombre: " + d.getProductos().getNombre());
				System.out.println("marca: " + d.getProductos().getMarcas().getNombreMarca());

			}

			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}

	@Ignore
	// @Test
	public void nuevoRegistro() {
		DetalleVentas detalleVentas = new DetalleVentas();
		System.out.println("Test nuevo registro de detalles ventas");
		try {
			detalleVentas.setVentaId(2);
			detalleVentas.setProductoId(4);
			detalleVentas.setCantidad(45);

			detalleVentasService.nuevaDetalleVentas(detalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	// @Test
	@Ignore
	public void actualizarRegistro() {
		DetalleVentas detalleVentas = new DetalleVentas();
		System.out.println("actualizar registro");
		try {
			detalleVentas.setVentaId(5);
			detalleVentas.setCantidad(1000);
			detalleVentas.setProductoId(1);

			detalleVentasService.actualizarDetalleVentas(detalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	// @Test
	@Ignore
	public void eliminarDetalleVentas() {
		
		Map<String, Integer> mapDetalleVentas = new HashMap<>();
		mapDetalleVentas.put("ventaId", 2);
		System.out.println("Eliminar ");
		try {
			detalleVentasService.eliminarDetalleVentas(mapDetalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

}
