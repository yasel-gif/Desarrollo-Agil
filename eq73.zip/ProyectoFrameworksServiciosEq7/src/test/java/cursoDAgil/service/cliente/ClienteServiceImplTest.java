package cursoDAgil.service.cliente;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.domain.Direccion;
import cursoDAgil.service.direccion.DireccionService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class ClienteServiceImplTest {
	
	@Inject
	ClienteService clienteservice;
	@Inject
	DireccionService direccionservice;
	@Ignore
	//@Test
	public void pruebaConsultarTodo() {
		int reg;
		try {
			List<Cliente> lista=clienteservice.listarTodosClientes();
			reg = lista.size();
			
			for(Cliente c:lista) {
				System.out.println("Id: " + c.getId());	
				System.out.println("Nombre: " + c.getNombre() );
				System.out.println("Calle: " + c.getDireccion().getCalle() );
				
				
			}
			
			assertEquals(lista.size(),reg);
			
		}catch(Exception e) {
			System.out.print("error: " + e);
		}
	}
	@Test
	//@Ignore
	public void consultarClientePorId() {
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 6);
		try {
			cliente = clienteservice.obtenerClientePorId(mapCliente);
			assertNotNull(cliente);
			System.out.println("id:" + cliente.getId());
			System.out.println("nombre:" + cliente.getNombre());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	
	}
	//@Test
	@Ignore
	public void actualizarRegistro() {
		Cliente cliente = new Cliente();
		System.out.println("actualizar registro");
		try {
			cliente.setId(1);
			cliente.setNombre("Ana");
			cliente.setApellido("Gonzalez");
			cliente.setEmail("ana@gmail.com");
			cliente.setSexo("F");
			cliente.setIdDireccion(1);
			
			clienteservice.actualizarCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Test
	@Ignore
	public void eliminarCliente() {
		Integer cliente;
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 10);
		System.out.println("Eliminar ");
		try {
			cliente = clienteservice.eliminarCliente(mapCliente);
			assertNotNull(cliente);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Test
	@Ignore
	public void nuevoRegistro() {
		Cliente cliente = new Cliente();
		Direccion direccion= new Direccion();
		Map<String, Integer> mapDireccion= new HashMap<>();
		mapDireccion.put("idDireccion",1);
		System.out.println("Test nuevo registro");
		try {
			
			cliente.setNombre("Daniela2");
			cliente.setApellido("Zurita");
			cliente.setEmail("da0ni@gmail.com");
			cliente.setSexo("F");
			cliente.setIdDireccion(1);
			direccion= direccionservice.obtenerDireccionPorId(mapDireccion);
			cliente.setIdDireccion(direccion.getIdDireccion());
			cliente.setDireccion(direccion);
			
			clienteservice.nuevoCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	

	
}