package cursoDAgil.service.marcas;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Marcas;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class MarcasServiceImplTest {

	@Inject
	MarcasService marcasService;

	//@Ignore
	@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas las marcas");
		try {
			List<Marcas> list = marcasService.obtenerMarcas();
			reg = list.size();
			for (Marcas m : list) {
				System.out.println("Id: " + m.getIdMarca());
				System.out.println("Id: " + m.getNombreMarca());
			}

			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}

	// @Test
	@Ignore
	public void nuevoRegistro() {
		Marcas marcas = new Marcas();
		System.out.println("Test nuevo registro");
		try {
			marcas.setNombreMarca("Bimbo");

			marcasService.nuevaMarcas(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	@Ignore
	//@Test
	public void consultarMarcasPorId() {
		Marcas marcas = new Marcas();
		Map<String, Integer> mapMarcas = new HashMap<>();
		mapMarcas.put("idMarca", 2);
		try {
			marcas = marcasService.obtenerMarcasPorId(mapMarcas);
			assertNotNull(marcas);
			System.out.println("id:" + marcas.getIdMarca());
			System.out.println("Nombre Marca:" + marcas.getNombreMarca());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	@Ignore
	//@Test
	public void actualizarRegistro() {
		Marcas marcas = new Marcas();
		System.out.println("actualizar registro");
		try {
			marcas.setIdMarca(5);
			marcas.setNombreMarca("Barcel");

			marcasService.actualizarMarcas(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	//@Test
	@Ignore
	public void eliminarMarcas() {
		Integer marcas;
		Map<String, Integer> mapMarcas = new HashMap<>();
		mapMarcas.put("idMarca", 5);
		System.out.println("Eliminar ");
		try {
			marcas = marcasService.eliminarMarcas(mapMarcas);
			assertNotNull(marcas);

		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

}
