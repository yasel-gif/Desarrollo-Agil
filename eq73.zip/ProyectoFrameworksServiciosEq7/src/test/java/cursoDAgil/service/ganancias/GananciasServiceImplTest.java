package cursoDAgil.service.ganancias;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Ganancias;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class GananciasServiceImplTest {
	@Inject
	GananciasService gananciasService;
	@Test
	//@Ignore
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas los Ganancias");
		try {
			List<Ganancias> list = gananciasService.obtenerGanancias();
			reg = list.size();
			
			for(Ganancias g:list) {
				System.out.println("Id: " + g.getIdGanancia());	
				System.out.println("Nombre: " + g.getVentaId() );
				System.out.println("IdDireccion: " + g.getTotalGanancia());
				
			}
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	//@Test
	@Ignore
	public void nuevoRegistro() {
		Ganancias ganancias = new Ganancias();
		System.out.println("Test nuevo registro");
		try {
			ganancias.setVentaId(1);
			ganancias.setTotalGanancia(500.0);
			//ganancias.setFecha(new Date());
			
			
			gananciasService.nuevaGanancias(ganancias);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void consultarVentasPorId() {
		Ganancias ganancias = new Ganancias();
		Map<String, Integer> mapGanancias = new HashMap<>();
		mapGanancias.put("idGanancia", 2);
		try {
			ganancias = gananciasService.obtenerGananciasPorId(mapGanancias);
			assertNotNull(ganancias);
			System.out.println("id:" + ganancias.getIdGanancia());
			System.out.println("venta id:" + ganancias.getVentaId());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
		public void consultarVentasPorFecha() {
			//Ganancias ganancias = new Ganancias();
			Map<String, String> mapGanancias = new HashMap<>();
			mapGanancias.put("fecha", "21-06-10");
			try {
				List<Ganancias> list = gananciasService.obtenerGananciasPorFecha(mapGanancias);
					
				for(Ganancias g:list) {	
					System.out.println("id:" + g.getIdGanancia());
					System.out.println("venta id:" + g.getVentaId());
				}
				
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
	//@Test
		@Ignore
		public void actualizarRegistro() {
			Ganancias ganancias = new Ganancias();
			System.out.println("actualizar registro");
			try {
				ganancias.setIdGanancia(1);
				ganancias.setVentaId(1);
				ganancias.setTotalGanancia(100.0);
				//ganancias.setFecha(new Date());
				
				
				
				gananciasService.actualizarGanancias(ganancias);
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
		//@Test
		@Ignore
		public void eliminarGanancias() {
			Integer ganancias;
			Map<String, Integer> mapGanancias = new HashMap<>();
			mapGanancias.put("idGanancia", 3);
			System.out.println("Eliminar ");
			try {
				ganancias = gananciasService.eliminarGanancias(mapGanancias);
				assertNotNull(ganancias);
				
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}	

}
