package cursoDAgil.service.productos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Productos;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class ProductosServiceImplTest {
	
	@Inject
	ProductosService productosService;
	
	@Test
	//@Ignore
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("Test consultar todas los productos");
		try {
			List<Productos> list = productosService.obtenerProductos();
			reg = list.size();
			
			for(Productos p:list) {
				System.out.println("Id: " + p.getIdProducto());	
				System.out.println("Nombre: " + p.getNombre() );
				System.out.println("Marca: " + p.getMarcas().getNombreMarca());
				
			}
			
			assertEquals(list.size(), reg);
			System.out.println("\nRegistros en la tabla: " + reg);
		} catch (Exception ex) {
			System.out.println("error" + ex);

		}
	}
	
	//@Test
	@Ignore
	public void consultarProductosPorId() {
		Productos productos = new Productos();
		Map<String, Integer> mapProductos = new HashMap<>();
		mapProductos.put("idProducto", 2);
		try {
			productos = productosService.obtenerProductosPorId(mapProductos);
			assertNotNull(productos);
			System.out.println("id:" + productos.getIdProducto());
			System.out.println("nombre:" + productos.getNombre());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	//@Test
	@Ignore
	public void eliminarProductos() {
		Integer productos;
		Map<String, Integer> mapProductos = new HashMap<>();
		mapProductos.put("idProducto", 6);
		System.out.println("Eliminar ");
		try {
			productos = productosService.eliminarProductos(mapProductos);
			assertNotNull(productos);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	//@Test
	@Ignore
	public void nuevoRegistro() {
		Productos productos = new Productos();
		System.out.println("Test nuevo registro");
		try {
			productos.setNombre("Donitas");
			productos.setPrecio(10.0);
			productos.setPrecioVta(16.0);
			productos.setCantidad(500);
			productos.setMarcaId(1);
			
			productosService.nuevoProductos(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Ignore
	//@Test
	public void actualizarRegistro() {
		Productos productos = new Productos();
		System.out.println("actualizar registro");
		try {
			productos.setIdProducto(6);
			productos.setNombre("Takis");
			productos.setPrecio(11.0);
			productos.setPrecioVta(16.0);
			productos.setCantidad(100);
			productos.setMarcaId(1);
			
			
			
			
			productosService.actualizarProductos(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

}
